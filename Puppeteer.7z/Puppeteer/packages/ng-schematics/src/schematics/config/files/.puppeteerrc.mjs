/**
 * @type {import("puppeteer").Configuration}
 */
export {};
