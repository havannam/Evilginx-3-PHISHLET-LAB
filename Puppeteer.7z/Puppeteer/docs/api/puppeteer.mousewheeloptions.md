---
sidebar_label: MouseWheelOptions
---

# MouseWheelOptions interface

### Signature

```typescript
export interface MouseWheelOptions
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th><th>

Default

</th></tr></thead>
<tbody><tr><td>

<span id="deltax">deltaX</span>

</td><td>

`optional`

</td><td>

number

</td><td>

</td><td>

</td></tr>
<tr><td>

<span id="deltay">deltaY</span>

</td><td>

`optional`

</td><td>

number

</td><td>

</td><td>

</td></tr>
</tbody></table>
