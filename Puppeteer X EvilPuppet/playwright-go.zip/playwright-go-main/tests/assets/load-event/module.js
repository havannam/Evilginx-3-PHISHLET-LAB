import {foo} from '/slow.js';
console.log('foo is', foo);
window.results.push('module');
