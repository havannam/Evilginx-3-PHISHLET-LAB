---
sidebar_label: WebWorker.url
---

# WebWorker.url() method

The URL of this web worker.

### Signature

```typescript
class WebWorker {
  url(): string;
}
```

**Returns:**

string
