function callme(cb) {
  return cb();
}

module.exports = callme;
