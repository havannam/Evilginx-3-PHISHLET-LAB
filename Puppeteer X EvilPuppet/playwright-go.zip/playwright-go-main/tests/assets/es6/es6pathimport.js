import num from './es6/es6module.js';
window.__es6injected = num;