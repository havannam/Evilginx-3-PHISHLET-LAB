---
sidebar_label: ExtensionTransport.connectTab
---

# ExtensionTransport.connectTab() method

### Signature

```typescript
class ExtensionTransport {
  static connectTab(tabId: number): Promise<ExtensionTransport>;
}
```

## Parameters

<table><thead><tr><th>

Parameter

</th><th>

Type

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

tabId

</td><td>

number

</td><td>

</td></tr>
</tbody></table>
**Returns:**

Promise&lt;[ExtensionTransport](./puppeteer.extensiontransport.md)&gt;
