---
sidebar_label: AwaitableIterable
---

# AwaitableIterable type

### Signature

```typescript
export type AwaitableIterable<T> = Iterable<T> | AsyncIterable<T>;
```
