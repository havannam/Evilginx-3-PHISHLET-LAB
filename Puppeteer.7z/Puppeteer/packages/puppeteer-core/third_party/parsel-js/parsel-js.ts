// esline-disable rulesdir/check-license
export {tokenize, TOKENS, stringify} from 'parsel-js';

export type * from 'parsel-js';
