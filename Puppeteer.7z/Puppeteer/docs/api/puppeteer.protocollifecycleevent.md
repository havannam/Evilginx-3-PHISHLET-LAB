---
sidebar_label: ProtocolLifeCycleEvent
---

# ProtocolLifeCycleEvent type

### Signature

```typescript
export type ProtocolLifeCycleEvent =
  | 'load'
  | 'DOMContentLoaded'
  | 'networkIdle'
  | 'networkAlmostIdle';
```
