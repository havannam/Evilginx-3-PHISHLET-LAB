---
sidebar_label: HTTPResponse.fromServiceWorker
---

# HTTPResponse.fromServiceWorker() method

True if the response was served by a service worker.

### Signature

```typescript
class HTTPResponse {
  abstract fromServiceWorker(): boolean;
}
```

**Returns:**

boolean
