---
sidebar_label: DebugInfo
---

# DebugInfo interface

### Signature

```typescript
export interface DebugInfo
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th><th>

Default

</th></tr></thead>
<tbody><tr><td>

<span id="pendingprotocolerrors">pendingProtocolErrors</span>

</td><td>

</td><td>

Error\[\]

</td><td>

</td><td>

</td></tr>
</tbody></table>
