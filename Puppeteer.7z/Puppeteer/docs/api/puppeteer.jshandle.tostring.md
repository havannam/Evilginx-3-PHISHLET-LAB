---
sidebar_label: JSHandle.toString
---

# JSHandle.toString() method

Returns a string representation of the JSHandle.

### Signature

```typescript
class JSHandle {
  abstract toString(): string;
}
```

**Returns:**

string

## Remarks

Useful during debugging.
