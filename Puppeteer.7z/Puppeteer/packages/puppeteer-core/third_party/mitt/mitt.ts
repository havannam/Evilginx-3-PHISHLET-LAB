// esline-disable rulesdir/check-license
export * from 'mitt';
export {default as default} from 'mitt';
