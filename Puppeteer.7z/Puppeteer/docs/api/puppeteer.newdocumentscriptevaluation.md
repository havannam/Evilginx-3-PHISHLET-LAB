---
sidebar_label: NewDocumentScriptEvaluation
---

# NewDocumentScriptEvaluation interface

### Signature

```typescript
export interface NewDocumentScriptEvaluation
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th><th>

Default

</th></tr></thead>
<tbody><tr><td>

<span id="identifier">identifier</span>

</td><td>

</td><td>

string

</td><td>

</td><td>

</td></tr>
</tbody></table>
