/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */

export const testChromeBuildId = '127.0.6533.72';
export const testChromiumBuildId = '1083080';
export const testFirefoxBuildId = 'stable_129.0';
export const testChromeDriverBuildId = '127.0.6533.72';
export const testChromeHeadlessShellBuildId = '127.0.6533.72';
