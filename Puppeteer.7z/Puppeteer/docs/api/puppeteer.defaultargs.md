---
sidebar_label: defaultArgs
---

# defaultArgs() function

### Signature

```typescript
defaultArgs: (options?: PuppeteerCore.BrowserLaunchArgumentOptions) => string[]
```

## Parameters

<table><thead><tr><th>

Parameter

</th><th>

Type

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

options

</td><td>

[PuppeteerCore.BrowserLaunchArgumentOptions](./puppeteer.browserlaunchargumentoptions.md)

</td><td>

_(Optional)_

</td></tr>
</tbody></table>
**Returns:**

string\[\]
