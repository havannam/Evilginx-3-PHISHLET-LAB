module.exports = {
  spec: './e2e/build/**/*.e2e.js',
  timeout: 5000,
};
