---
sidebar_label: HTTPResponse.ok
---

# HTTPResponse.ok() method

True if the response was successful (status in the range 200-299).

### Signature

```typescript
class HTTPResponse {
  ok(): boolean;
}
```

**Returns:**

boolean
